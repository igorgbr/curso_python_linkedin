def condicionais():
    x, y = 100, 100

    if(x < y):
        print("x é menor do que y")
    elif(x == y):
        print("x é igual a y")
    else:
        print("x é maior que y")


condicionais()
